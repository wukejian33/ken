﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 'Hello World' Coding Exercise created by Kejian(Ken) Wu 
//  12/2017
namespace HelloWorld
{
    class HelloWorldTest
    {
        static void Main(string[] args)
        {
            MobileHellWord MoblieHello = new MobileHellWord();
            MoblieHello.WriteHelloWorld();

            WebHellWord WebHello = new WebHellWord();
            WebHello.WriteHelloWorld();

            ConsoleHellWord ConsoleHello = new ConsoleHellWord();
            ConsoleHello.WriteHelloWorld();

            WindowServicesHellWord WindowServicesHello = new WindowServicesHellWord();
            WindowServicesHello.WriteHelloWorld();

            System.Threading.Thread.Sleep(99999);
        }
    } // end class HelloWorldTest

    // The abstract class can inherit from other abstract classes or another interface for future enhancements as needed
    public abstract class HelloWorld // API
    {
        public abstract string WriteHelloWorld(); 
    } // end abstract class HelloWorld

    public class MobileHellWord : HelloWorld
    {
        public override string WriteHelloWorld()
        {
            Console.WriteLine("Moblie Hello World");
            // Future Enhancements (e.g. Write to database, console application, etc.)
            // Or public class DatabaseMobileHellWord : MobileHellWord
            // .... etc.
            return "Moblie";
        }
    } // end class MobileHellWord

    public class WebHellWord : HelloWorld
    {
        public override string WriteHelloWorld()
        {
            Console.WriteLine("Web Hello World");
            // Future Enhancements (e.g. Write to database, console application, etc.)
            // Or public class DatabaseWebHellWord : WebHellWord
            // .... etc.
            return "Web";
        }
    } // end class WebHellWord

    public class ConsoleHellWord : HelloWorld
    {
        public override string WriteHelloWorld()
        {
            Console.WriteLine("Console Hello World");
            // Future Enhancements (e.g. Write to database, console application, etc.)
            // Or public class DatabaseConsoleHellWord : ConsoleHellWord
            // .... etc.
            return "Console";
        }
    } // end class ConsoleHellWord

    public class WindowServicesHellWord : HelloWorld
    {
        public override string WriteHelloWorld()
        {
            Console.WriteLine("WindowServices Hello World");
            // Future Enhancements (e.g. Write to database, console application, etc.)
            // Or public class DatabaseWindowServicesHellWord : WindowServicesHellWord 
            // .... etc.
            return "Console";
        }
    } // end class WindowServicesHellWord
}
